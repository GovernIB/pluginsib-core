package org.fundaciobit.plugins;
/**
 * 
 * @author anadal
 *
 */
public interface IPlugin {

  public static final String IPLUGIN_BASE_PROPERTIES = "plugins."; 
  
}
